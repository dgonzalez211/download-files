function sky-islands:island/overworld/random_position
data modify storage forceload-async:data input.callback set value "sky-islands:island/overworld/ruined_portal/validate"

function forceload-async:forceload