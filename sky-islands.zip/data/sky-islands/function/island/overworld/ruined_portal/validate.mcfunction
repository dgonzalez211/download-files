execute if function sky-islands:island/overworld/is_valid run return run function sky-islands:island/overworld/ruined_portal/place
function sky-islands:island/overworld/ruined_portal/load