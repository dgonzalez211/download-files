summon minecraft:marker ~ ~ ~ {Tags: ["sky-islands.island", "sky-islands.beach"]}
place template sky-islands:beach

# --- Layer 1 (Y starts at 0, height 20) ---
execute positioned ~0 ~0 ~0 run fillbiome ~ ~ ~ ~30 ~20 ~30 minecraft:beach
execute positioned ~30 ~0 ~0 run fillbiome ~ ~ ~ ~2 ~20 ~30 minecraft:beach
execute positioned ~0 ~0 ~30 run fillbiome ~ ~ ~ ~30 ~20 ~2 minecraft:beach
execute positioned ~30 ~0 ~30 run fillbiome ~ ~ ~ ~2 ~20 ~2 minecraft:beach

# --- Layer 2 (Y starts at 20, height 20) ---
execute positioned ~0 ~20 ~0 run fillbiome ~ ~ ~ ~30 ~20 ~30 minecraft:beach
execute positioned ~30 ~20 ~0 run fillbiome ~ ~ ~ ~2 ~20 ~30 minecraft:beach
execute positioned ~0 ~20 ~30 run fillbiome ~ ~ ~ ~30 ~20 ~2 minecraft:beach
execute positioned ~30 ~20 ~30 run fillbiome ~ ~ ~ ~2 ~20 ~2 minecraft:beach

# --- Layer 3 (Y starts at 40, height 10) ---
execute positioned ~0 ~40 ~0 run fillbiome ~ ~ ~ ~30 ~10 ~30 minecraft:beach
execute positioned ~30 ~40 ~0 run fillbiome ~ ~ ~ ~2 ~10 ~30 minecraft:beach
execute positioned ~0 ~40 ~30 run fillbiome ~ ~ ~ ~30 ~10 ~2 minecraft:beach
execute positioned ~30 ~40 ~30 run fillbiome ~ ~ ~ ~2 ~10 ~2 minecraft:beach