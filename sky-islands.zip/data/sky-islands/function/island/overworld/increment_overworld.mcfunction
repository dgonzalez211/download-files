#constants
scoreboard players set #validation_fail_threshold_overworld sky-islands.tmp 10

#increment after X retries
execute if function sky-islands:island/overworld/check_fails run scoreboard players add #random_range_overworld sky-islands.tmp 20
execute if score #validation_fails_overworld sky-islands.tmp > #validation_fail_threshold_overworld sky-islands.tmp run scoreboard players set #validation_fails_overworld sky-islands.tmp 0
