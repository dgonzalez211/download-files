function sky-islands:island/overworld/random_position
data modify storage forceload-async:data input.callback set value "sky-islands:island/overworld/village/validate"

function forceload-async:forceload