execute if function sky-islands:island/overworld/is_valid run return run function sky-islands:island/overworld/village/place
function sky-islands:island/overworld/village/load