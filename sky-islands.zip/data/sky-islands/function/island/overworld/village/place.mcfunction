summon minecraft:marker ~ ~ ~ {Tags: ["sky-islands.island", "sky-islands.village"]}
place template sky-islands:village

# Bottom Layer (Y = -20)
execute positioned ~-20 ~-20 ~-20 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~0 ~-20 ~-20 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~20 ~-20 ~-20 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~-20 ~-20 ~0 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~0 ~-20 ~0 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~20 ~-20 ~0 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~-20 ~-20 ~20 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~0 ~-20 ~20 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~20 ~-20 ~20 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest

# Middle Layer (Y = 0)
execute positioned ~-20 ~0 ~-20 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~0 ~0 ~-20 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~20 ~0 ~-20 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~-20 ~0 ~0 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~0 ~0 ~0 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~20 ~0 ~0 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~-20 ~0 ~20 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~0 ~0 ~20 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~20 ~0 ~20 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest

# Top Layer (Y = 20)
execute positioned ~-20 ~20 ~-20 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~0 ~20 ~-20 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~20 ~20 ~-20 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~-20 ~20 ~0 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~0 ~20 ~0 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~20 ~20 ~0 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~-20 ~20 ~20 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~0 ~20 ~20 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest
execute positioned ~20 ~20 ~20 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:flower_forest