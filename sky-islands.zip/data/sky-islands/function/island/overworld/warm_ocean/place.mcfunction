summon minecraft:marker ~ ~ ~ {Tags: ["sky-islands.island", "sky-islands.warm_ocean"]}
place template sky-islands:warm_ocean

execute positioned ~ ~-20 ~ run function sky-islands:island/overworld/warm_ocean/warm_ocean_fillbiome