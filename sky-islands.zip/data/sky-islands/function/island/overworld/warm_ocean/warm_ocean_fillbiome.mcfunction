
# --- Layer 1 (Y offset: 0) ---
execute positioned ~0 ~0 ~0 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:warm_ocean
execute positioned ~20 ~0 ~0 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:warm_ocean
execute positioned ~40 ~0 ~0 run fillbiome ~ ~ ~ ~9 ~19 ~19 minecraft:warm_ocean
execute positioned ~0 ~0 ~20 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:warm_ocean
execute positioned ~20 ~0 ~20 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:warm_ocean
execute positioned ~40 ~0 ~20 run fillbiome ~ ~ ~ ~9 ~19 ~19 minecraft:warm_ocean
execute positioned ~0 ~0 ~40 run fillbiome ~ ~ ~ ~19 ~19 ~9 minecraft:warm_ocean
execute positioned ~20 ~0 ~40 run fillbiome ~ ~ ~ ~19 ~19 ~9 minecraft:warm_ocean
execute positioned ~40 ~0 ~40 run fillbiome ~ ~ ~ ~9 ~19 ~9 minecraft:warm_ocean

# --- Layer 2 (Y offset: 20) ---
execute positioned ~0 ~20 ~0 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:warm_ocean
execute positioned ~20 ~20 ~0 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:warm_ocean
execute positioned ~40 ~20 ~0 run fillbiome ~ ~ ~ ~9 ~19 ~19 minecraft:warm_ocean
execute positioned ~0 ~20 ~20 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:warm_ocean
execute positioned ~20 ~20 ~20 run fillbiome ~ ~ ~ ~19 ~19 ~19 minecraft:warm_ocean
execute positioned ~40 ~20 ~20 run fillbiome ~ ~ ~ ~9 ~19 ~19 minecraft:warm_ocean
execute positioned ~0 ~20 ~40 run fillbiome ~ ~ ~ ~19 ~19 ~9 minecraft:warm_ocean
execute positioned ~20 ~20 ~40 run fillbiome ~ ~ ~ ~19 ~19 ~9 minecraft:warm_ocean
execute positioned ~40 ~20 ~40 run fillbiome ~ ~ ~ ~9 ~19 ~9 minecraft:warm_ocean

# --- Layer 3 (Y offset: 40) ---
execute positioned ~0 ~40 ~0 run fillbiome ~ ~ ~ ~19 ~9 ~19 minecraft:warm_ocean
execute positioned ~20 ~40 ~0 run fillbiome ~ ~ ~ ~19 ~9 ~19 minecraft:warm_ocean
execute positioned ~40 ~40 ~0 run fillbiome ~ ~ ~ ~9 ~9 ~19 minecraft:warm_ocean
execute positioned ~0 ~40 ~20 run fillbiome ~ ~ ~ ~19 ~9 ~19 minecraft:warm_ocean
execute positioned ~20 ~40 ~20 run fillbiome ~ ~ ~ ~19 ~9 ~19 minecraft:warm_ocean
execute positioned ~40 ~40 ~20 run fillbiome ~ ~ ~ ~9 ~9 ~19 minecraft:warm_ocean
execute positioned ~0 ~40 ~40 run fillbiome ~ ~ ~ ~19 ~9 ~9 minecraft:warm_ocean
execute positioned ~20 ~40 ~40 run fillbiome ~ ~ ~ ~19 ~9 ~9 minecraft:warm_ocean
execute positioned ~40 ~40 ~40 run fillbiome ~ ~ ~ ~9 ~9 ~9 minecraft:warm_ocean