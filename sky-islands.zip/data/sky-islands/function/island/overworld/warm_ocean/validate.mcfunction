execute if function sky-islands:island/overworld/is_valid run return run function sky-islands:island/overworld/warm_ocean/place
function sky-islands:island/overworld/warm_ocean/load