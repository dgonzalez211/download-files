function sky-islands:island/overworld/random_position
data modify storage forceload-async:data input.callback set value "sky-islands:island/overworld/warm_ocean/validate"

function forceload-async:forceload