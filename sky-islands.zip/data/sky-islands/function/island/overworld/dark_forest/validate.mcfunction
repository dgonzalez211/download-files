execute if function sky-islands:island/overworld/is_valid run return run function sky-islands:island/overworld/dark_forest/place
function sky-islands:island/overworld/dark_forest/load