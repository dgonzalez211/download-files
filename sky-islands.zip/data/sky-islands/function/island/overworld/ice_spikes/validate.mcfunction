execute if function sky-islands:island/overworld/is_valid run return run function sky-islands:island/overworld/ice_spikes/place
function sky-islands:island/overworld/ice_spikes/load