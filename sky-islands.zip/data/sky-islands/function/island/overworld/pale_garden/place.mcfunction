summon minecraft:marker ~ ~ ~ {Tags: ["sky-islands.island", "sky-islands.pale_garden"]}
place template sky-islands:pale_garden

execute positioned ~0 ~0 ~0 run fillbiome ~ ~ ~ ~20 ~20 ~20 minecraft:pale_garden
execute positioned ~20 ~0 ~0 run fillbiome ~ ~ ~ ~20 ~20 ~20 minecraft:pale_garden
execute positioned ~0 ~0 ~20 run fillbiome ~ ~ ~ ~20 ~20 ~20 minecraft:pale_garden
execute positioned ~20 ~0 ~20 run fillbiome ~ ~ ~ ~20 ~20 ~20 minecraft:pale_garden

execute positioned ~0 ~20 ~0 run fillbiome ~ ~ ~ ~20 ~20 ~20 minecraft:pale_garden
execute positioned ~20 ~20 ~0 run fillbiome ~ ~ ~ ~20 ~20 ~20 minecraft:pale_garden
execute positioned ~0 ~20 ~20 run fillbiome ~ ~ ~ ~20 ~20 ~20 minecraft:pale_garden
execute positioned ~20 ~20 ~20 run fillbiome ~ ~ ~ ~20 ~20 ~20 minecraft:pale_garden