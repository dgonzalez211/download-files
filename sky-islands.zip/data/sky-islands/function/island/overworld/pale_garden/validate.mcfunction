execute if function sky-islands:island/overworld/is_valid run return run function sky-islands:island/overworld/pale_garden/place
function sky-islands:island/overworld/pale_garden/load