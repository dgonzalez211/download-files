## Spawn
function sky-islands:island/overworld/spawn/load

## Deep Dark
function sky-islands:island/overworld/deep_dark/load

## Stronghold
function sky-islands:island/overworld/stronghold/load

## Pale Garden
function sky-islands:island/overworld/pale_garden/load

## Warm Ocean
function sky-islands:island/overworld/warm_ocean/load

## Village
function sky-islands:island/overworld/village/load

## Dark Forest
function sky-islands:island/overworld/dark_forest/load

## Taiga
function sky-islands:island/overworld/taiga/load

## Mangrove
function sky-islands:island/overworld/mangrove/load

## Deepslate Basalt
function sky-islands:island/overworld/deepslate_basalt/load

## Ice Spikes
function sky-islands:island/overworld/ice_spikes/load

## Beach
function sky-islands:island/overworld/beach/load

## Cherry Grove
function sky-islands:island/overworld/cherry_grove/load

## Savanna
function sky-islands:island/overworld/savanna/load

## Meadow
function sky-islands:island/overworld/meadow/load

## Jungle
function sky-islands:island/overworld/jungle/load

## Ruined Portal
function sky-islands:island/overworld/ruined_portal/load