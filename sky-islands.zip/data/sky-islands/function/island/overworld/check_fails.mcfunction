execute unless score #validation_fails_overworld sky-islands.tmp >= #validation_fail_threshold_overworld sky-islands.tmp run return fail
return 1