execute if function sky-islands:island/overworld/is_valid run return run function sky-islands:island/overworld/cherry_grove/place
function sky-islands:island/overworld/cherry_grove/load