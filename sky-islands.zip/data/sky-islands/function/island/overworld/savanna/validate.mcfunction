execute if function sky-islands:island/overworld/is_valid run return run function sky-islands:island/overworld/savanna/place
function sky-islands:island/overworld/savanna/load