execute if function sky-islands:island/overworld/is_valid run return run function sky-islands:island/overworld/deepslate_basalt/place
function sky-islands:island/overworld/deepslate_basalt/load