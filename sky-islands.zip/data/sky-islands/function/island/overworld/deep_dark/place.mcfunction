summon minecraft:marker ~ ~-15 ~ {Tags: ["sky-islands.pending", "sky-islands.deep_dark"]}

schedule function sky-islands:island/overworld/deep_dark/template1 2t
schedule function sky-islands:island/overworld/deep_dark/template2 4t
schedule function sky-islands:island/overworld/deep_dark/template3 6t
schedule function sky-islands:island/overworld/deep_dark/template4 8t
schedule function sky-islands:island/overworld/deep_dark/template5 10t
schedule function sky-islands:island/overworld/deep_dark/template6 12t
schedule function sky-islands:island/overworld/deep_dark/template7 14t
schedule function sky-islands:island/overworld/deep_dark/template8 16t

execute positioned ~ ~ ~ run function sky-islands:island/overworld/deep_dark/fillbiome
