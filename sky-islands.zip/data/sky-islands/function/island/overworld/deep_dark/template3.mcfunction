execute as @n[tag=sky-islands.deep_dark] at @s positioned ~ ~-15 ~36 run place template sky-islands:deep_dark_3
