execute as @n[tag=sky-islands.deep_dark] at @s positioned ~36 ~21 ~36 run place template sky-islands:deep_dark_8

tag @n[tag=sky-islands.deep_dark] remove sky-islands.pending
tag @n[tag=sky-islands.deep_dark] add sky-islands.island