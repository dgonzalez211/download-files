execute as @n[tag=sky-islands.deep_dark] at @s positioned ~ ~21 ~36 run place template sky-islands:deep_dark_7
