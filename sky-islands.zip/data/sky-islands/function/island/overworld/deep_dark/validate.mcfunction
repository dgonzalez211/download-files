execute if function sky-islands:island/overworld/is_valid run return run function sky-islands:island/overworld/deep_dark/place
function sky-islands:island/overworld/deep_dark/load