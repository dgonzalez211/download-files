execute as @n[tag=sky-islands.deep_dark] at @s positioned ~36 ~21 ~ run place template sky-islands:deep_dark_6
