function sky-islands:island/overworld/increment_overworld
scoreboard players add #validation_fails_overworld sky-islands.tmp 1
execute if entity @n[tag=sky-islands.island,distance=0.1..112] run return fail
execute if entity @n[tag=sky-islands.pending,distance=0.1..112] run return fail
return 1