execute if data storage sky-islands:init {overworld:{loaded:1}} run return fail
scoreboard players set #overworld.count sky-islands.tmp 0
execute as @e[tag=sky-islands.island] at @s if predicate sky-islands:in_overworld run scoreboard players add #overworld.count sky-islands.tmp 1
execute if score #overworld.count sky-islands.tmp matches ..16 run return fail

execute in minecraft:overworld run forceload remove all

data modify storage sky-islands:init overworld.loaded set value 1b