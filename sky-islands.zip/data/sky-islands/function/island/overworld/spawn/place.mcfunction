setworldspawn ~8 ~13 ~10
tp @a ~8 ~13 ~10
summon minecraft:marker ~ ~ ~ {Tags: ["sky-islands.island", "sky-islands.spawn_island"]}
place template sky-islands:spawn_island

# --- Layer 1 (Y starts at 0, height 20) ---
execute positioned ~0 ~0 ~0 run fillbiome ~ ~ ~ ~30 ~20 ~30 minecraft:plains
execute positioned ~30 ~0 ~0 run fillbiome ~ ~ ~ ~2 ~20 ~30 minecraft:plains
execute positioned ~0 ~0 ~30 run fillbiome ~ ~ ~ ~30 ~20 ~2 minecraft:plains
execute positioned ~30 ~0 ~30 run fillbiome ~ ~ ~ ~2 ~20 ~2 minecraft:plains

# --- Layer 2 (Y starts at 20, height 20) ---
execute positioned ~0 ~20 ~0 run fillbiome ~ ~ ~ ~30 ~20 ~30 minecraft:plains
execute positioned ~30 ~20 ~0 run fillbiome ~ ~ ~ ~2 ~20 ~30 minecraft:plains
execute positioned ~0 ~20 ~30 run fillbiome ~ ~ ~ ~30 ~20 ~2 minecraft:plains
execute positioned ~30 ~20 ~30 run fillbiome ~ ~ ~ ~2 ~20 ~2 minecraft:plains

# --- Layer 3 (Y starts at 40, height 10) ---
execute positioned ~0 ~40 ~0 run fillbiome ~ ~ ~ ~30 ~10 ~30 minecraft:plains
execute positioned ~30 ~40 ~0 run fillbiome ~ ~ ~ ~2 ~10 ~30 minecraft:plains
execute positioned ~0 ~40 ~30 run fillbiome ~ ~ ~ ~30 ~10 ~2 minecraft:plains
execute positioned ~30 ~40 ~30 run fillbiome ~ ~ ~ ~2 ~10 ~2 minecraft:plains