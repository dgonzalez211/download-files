data modify storage forceload-async:data input.to.x.relative set value 32
data modify storage forceload-async:data input.to.z.relative set value 32

data modify storage forceload-async:data input.callback set value "sky-islands:island/overworld/spawn/place"

execute positioned 0 70 0 run function forceload-async:forceload