execute if function sky-islands:island/overworld/is_valid run return run function sky-islands:island/overworld/stronghold/place
function sky-islands:island/overworld/stronghold/load