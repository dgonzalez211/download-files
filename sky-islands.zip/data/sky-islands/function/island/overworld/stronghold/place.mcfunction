summon minecraft:marker ~ ~-5 ~ {Tags: ["sky-islands.island", "sky-islands.stronghold"]}
execute positioned ~ ~-5 ~ run place template sky-islands:stronghold

# --- Layer 1 (Y starts at 0, height 20) ---
execute positioned ~2 ~0 ~2 run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:purple_swamp
execute positioned ~32 ~0 ~2 run fillbiome ~ ~ ~ ~2 ~20 ~30 sky-islands:purple_swamp
execute positioned ~2 ~0 ~32 run fillbiome ~ ~ ~ ~30 ~20 ~2 sky-islands:purple_swamp
execute positioned ~32 ~0 ~32 run fillbiome ~ ~ ~ ~2 ~20 ~2 sky-islands:purple_swamp

# --- Layer 2 (Y starts at 20, height 20) ---
execute positioned ~2 ~20 ~2 run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:purple_swamp
execute positioned ~32 ~20 ~2 run fillbiome ~ ~ ~ ~2 ~20 ~30 sky-islands:purple_swamp
execute positioned ~2 ~20 ~32 run fillbiome ~ ~ ~ ~30 ~20 ~2 sky-islands:purple_swamp
execute positioned ~32 ~20 ~32 run fillbiome ~ ~ ~ ~2 ~20 ~2 sky-islands:purple_swamp

# --- Layer 3 (Y starts at 40, height 10) ---
execute positioned ~2 ~40 ~2 run fillbiome ~ ~ ~ ~30 ~10 ~30 sky-islands:purple_swamp
execute positioned ~32 ~40 ~2 run fillbiome ~ ~ ~ ~2 ~10 ~30 sky-islands:purple_swamp
execute positioned ~2 ~40 ~32 run fillbiome ~ ~ ~ ~30 ~10 ~2 sky-islands:purple_swamp
execute positioned ~32 ~40 ~32 run fillbiome ~ ~ ~ ~2 ~10 ~2 sky-islands:purple_swamp