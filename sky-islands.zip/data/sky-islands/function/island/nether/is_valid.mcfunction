function sky-islands:island/nether/increment_nether
scoreboard players add #validation_fails_nether sky-islands.tmp 1
execute if entity @n[tag=sky-islands.island,distance=..112] run return fail
execute if entity @n[tag=sky-islands.pending,distance=..112] run return fail
return 1