execute if function sky-islands:island/nether/is_valid run return run function sky-islands:island/nether/fortress/place
function sky-islands:island/nether/fortress/load