function sky-islands:island/nether/random_position
data modify storage forceload-async:data input.callback set value "sky-islands:island/nether/fortress/validate"

function forceload-async:forceload