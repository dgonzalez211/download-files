summon minecraft:marker ~ ~ ~ {Tags: ["sky-islands.island", "sky-islands.fortress"]}

place template sky-islands:fortress_part1
execute positioned ~48 ~ ~ run place template sky-islands:fortress_part2

# --- Ground Layer ---
fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~30 ~ ~ run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~60 ~ ~ run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~ ~ ~30 run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~30 ~ ~30 run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~60 ~ ~30 run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~ ~ ~60 run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~30 ~ ~60 run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~60 ~ ~60 run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes

# --- Middle Layer (Starts 20 blocks up) ---
execute positioned ~ ~20 ~ run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~30 ~20 ~ run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~60 ~20 ~ run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~ ~20 ~30 run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~30 ~20 ~30 run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~60 ~20 ~30 run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~ ~20 ~60 run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~30 ~20 ~60 run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~60 ~20 ~60 run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes

# --- Top Layer (Starts 40 blocks up) ---
execute positioned ~ ~40 ~ run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~30 ~40 ~ run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~60 ~40 ~ run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~ ~40 ~30 run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~30 ~40 ~30 run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~60 ~40 ~30 run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~ ~40 ~60 run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~30 ~40 ~60 run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes
execute positioned ~60 ~40 ~60 run fillbiome ~ ~ ~ ~30 ~20 ~30 sky-islands:red_nether_wastes