execute unless score #validation_fails_nether sky-islands.tmp >= #validation_fail_threshold_nether sky-islands.tmp run return fail
return 1