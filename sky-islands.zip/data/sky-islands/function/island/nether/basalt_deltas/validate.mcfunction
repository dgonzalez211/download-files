execute if function sky-islands:island/nether/is_valid run return run function sky-islands:island/nether/basalt_deltas/place
function sky-islands:island/nether/basalt_deltas/load