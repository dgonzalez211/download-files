summon minecraft:marker ~ ~-15 ~ {Tags: ["sky-islands.island", "sky-islands.basalt_deltas"]}
execute positioned ~ ~-20 ~ run place template sky-islands:basalt_deltas

# --- Ground Layer (Y offset: +0) ---
execute positioned ~0 ~-15 ~0 run fillbiome ~ ~ ~ ~30 ~20 ~30 minecraft:basalt_deltas
execute positioned ~30 ~-15 ~0 run fillbiome ~ ~ ~ ~30 ~20 ~30 minecraft:basalt_deltas
execute positioned ~0 ~-15 ~30 run fillbiome ~ ~ ~ ~30 ~20 ~30 minecraft:basalt_deltas
execute positioned ~30 ~-15 ~30 run fillbiome ~ ~ ~ ~30 ~20 ~30 minecraft:basalt_deltas

# --- Upper Layer (Y offset: +20) ---
execute positioned ~0 ~5 ~0 run fillbiome ~ ~ ~ ~30 ~20 ~30 minecraft:basalt_deltas
execute positioned ~30 ~5 ~0 run fillbiome ~ ~ ~ ~30 ~20 ~30 minecraft:basalt_deltas
execute positioned ~0 ~5 ~30 run fillbiome ~ ~ ~ ~30 ~20 ~30 minecraft:basalt_deltas
execute positioned ~30 ~5 ~30 run fillbiome ~ ~ ~ ~30 ~20 ~30 minecraft:basalt_deltas
