## Crimson Forest
function sky-islands:island/nether/crimson_forest/load

## Warped Forest
function sky-islands:island/nether/warped_forest/load

## Fortress
function sky-islands:island/nether/fortress/load

## Basalt Deltas
function sky-islands:island/nether/basalt_deltas/load

## Nether Wastes
#function sky-islands:island/nether/nether_wastes/load