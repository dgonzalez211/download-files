execute if function sky-islands:island/nether/is_valid run return run function sky-islands:island/nether/crimson_forest/place
function sky-islands:island/nether/crimson_forest/load