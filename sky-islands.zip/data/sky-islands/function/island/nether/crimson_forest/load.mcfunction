function sky-islands:island/nether/random_position
data modify storage forceload-async:data input.callback set value "sky-islands:island/nether/crimson_forest/validate"

function forceload-async:forceload