summon minecraft:marker ~ ~ ~ {Tags: ["sky-islands.island", "sky-islands.crimson_forest"]}
place template sky-islands:crimson_forest

# --- Ground Layer (Y offset: +0) ---
execute positioned ~0 ~0 ~0 run fillbiome ~ ~ ~ ~30 ~20 ~30 minecraft:crimson_forest
execute positioned ~30 ~0 ~0 run fillbiome ~ ~ ~ ~30 ~20 ~30 minecraft:crimson_forest
execute positioned ~0 ~0 ~30 run fillbiome ~ ~ ~ ~30 ~20 ~30 minecraft:crimson_forest
execute positioned ~30 ~0 ~30 run fillbiome ~ ~ ~ ~30 ~20 ~30 minecraft:crimson_forest

# --- Upper Layer (Y offset: +20) ---
execute positioned ~0 ~20 ~0 run fillbiome ~ ~ ~ ~30 ~20 ~30 minecraft:crimson_forest
execute positioned ~30 ~20 ~0 run fillbiome ~ ~ ~ ~30 ~20 ~30 minecraft:crimson_forest
execute positioned ~0 ~20 ~30 run fillbiome ~ ~ ~ ~30 ~20 ~30 minecraft:crimson_forest
execute positioned ~30 ~20 ~30 run fillbiome ~ ~ ~ ~30 ~20 ~30 minecraft:crimson_forest