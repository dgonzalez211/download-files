execute if data storage sky-islands:init {nether:{loaded:1}} run return fail
scoreboard players set #nether.count sky-islands.tmp 0
execute as @e[tag=sky-islands.island,tag=!sky-islands.nether_spawn] at @s if predicate sky-islands:in_nether run scoreboard players add #nether.count sky-islands.tmp 1
execute if score #nether.count sky-islands.tmp matches ..4 run return fail

execute in minecraft:the_nether run forceload remove all

data modify storage sky-islands:init nether.loaded set value 1b