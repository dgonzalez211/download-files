execute positioned ~-8 ~-20 ~-5 run function sky-islands:island/nether/spawn/place

data modify storage sky-islands:init nether.version set value 1

function sky-islands:island/nether/load