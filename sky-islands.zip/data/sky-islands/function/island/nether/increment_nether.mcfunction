#constants
scoreboard players set #validation_fail_threshold_nether sky-islands.tmp 10

#increment after threshold overflow
execute if function sky-islands:island/nether/check_fails run scoreboard players add #random_range_nether sky-islands.tmp 20
execute if score #validation_fails_nether sky-islands.tmp > #validation_fail_threshold_nether sky-islands.tmp run scoreboard players set #validation_fails_nether sky-islands.tmp 0
