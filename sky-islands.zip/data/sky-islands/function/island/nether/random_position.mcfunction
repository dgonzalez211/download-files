# constants
scoreboard players set #random_factor sky-islands.tmp 100000
scoreboard players set #2 sky-islands.tmp 2

# calculate half range
scoreboard players operation #half_range sky-islands.tmp = #random_range_nether sky-islands.tmp
scoreboard players operation #half_range sky-islands.tmp /= #2 sky-islands.tmp

# x
execute store result score #x sky-islands.tmp run random value 0..100000
scoreboard players operation #x sky-islands.tmp *= #random_range_nether sky-islands.tmp
scoreboard players operation #x sky-islands.tmp /= #random_factor sky-islands.tmp
scoreboard players operation #x sky-islands.tmp -= #half_range sky-islands.tmp

# z
execute store result score #z sky-islands.tmp run random value 0..100000
scoreboard players operation #z sky-islands.tmp *= #random_range_nether sky-islands.tmp
scoreboard players operation #z sky-islands.tmp /= #random_factor sky-islands.tmp
scoreboard players operation #z sky-islands.tmp -= #half_range sky-islands.tmp

execute store result storage forceload-async:data input.context.x int 1 run scoreboard players get #x sky-islands.tmp
execute store result storage forceload-async:data input.context.y int 1 run random value 50..70
execute store result storage forceload-async:data input.context.z int 1 run scoreboard players get #z sky-islands.tmp

data modify storage forceload-async:data input.to.x.relative set value 64
data modify storage forceload-async:data input.to.z.relative set value 64