data modify storage forceload-async:data input.to.x.relative set value 16
data modify storage forceload-async:data input.to.z.relative set value 16

data modify storage forceload-async:data input.callback set value "sky-islands:island/nether/spawn/place"

execute positioned 0 100 0 run function forceload-async:forceload

