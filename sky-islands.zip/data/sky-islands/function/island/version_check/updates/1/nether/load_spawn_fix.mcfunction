data modify storage forceload-async:data input.from.x.relative set value -112
data modify storage forceload-async:data input.from.z.relative set value -112
data modify storage forceload-async:data input.to.x.relative set value 112
data modify storage forceload-async:data input.to.z.relative set value 112
data modify storage forceload-async:data input.callback set value "sky-islands:island/version_check/updates/1/nether/validate_spawn"

function forceload-async:forceload