function sky-islands:island/version_check/fill_space

# Update from 0 to 1
execute unless data storage sky-islands:init nether.version run function sky-islands:island/version_check/updates/1/nether/1

# Update from 1 to 2
# execute if data storage sky-islands:init {nether:{version:1}} run function sky-islands:island/version_check/updates/2/nether/2