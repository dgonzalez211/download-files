execute if function sky-islands:island/version_check/updates/1/overworld/is_space_valid run return run function sky-islands:island/overworld/village/place
function sky-islands:island/version_check/updates/1/overworld/village/load

