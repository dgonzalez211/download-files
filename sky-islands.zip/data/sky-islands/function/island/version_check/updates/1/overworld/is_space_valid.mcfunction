execute unless function sky-islands:island/overworld/is_valid run return fail
execute unless blocks ~ ~ ~ ~64 ~64 ~64 20000000 200 20000000 all run return fail
return 1