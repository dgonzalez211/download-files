function sky-islands:island/version_check/updates/1/nether/load_spawn_fix
function sky-islands:island/version_check/updates/1/nether/basalt_deltas/load
data modify storage sky-islands:init nether.version set value 1
