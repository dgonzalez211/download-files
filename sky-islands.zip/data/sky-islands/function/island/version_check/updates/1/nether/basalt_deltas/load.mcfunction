function sky-islands:island/version_check/updates/1/nether/random_position
data modify storage forceload-async:data input.callback set value "sky-islands:island/version_check/updates/1/nether/basalt_deltas/validate"

function forceload-async:forceload