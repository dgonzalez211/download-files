execute if data storage sky-islands:init {nether:{version:1}} run return fail
#                                                 ^ update latest version
data modify storage forceload-async:data input.to.x.relative set value 80
data modify storage forceload-async:data input.to.z.relative set value 80
data modify storage forceload-async:data input.callback set value "sky-islands:island/version_check/updates/1/nether/run"
execute positioned 20000000 200 20000000 run function forceload-async:forceload