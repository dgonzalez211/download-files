function sky-islands:island/overworld/random_position

data modify storage forceload-async:data input.from.x.relative set value -112
data modify storage forceload-async:data input.from.z.relative set value -112
data modify storage forceload-async:data input.to.x.relative set value 176
data modify storage forceload-async:data input.to.z.relative set value 176