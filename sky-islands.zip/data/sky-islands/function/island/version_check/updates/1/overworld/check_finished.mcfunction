execute if data storage sky-islands:init {overworld:{updated:1}} run return fail
scoreboard players set #overworld.upate-count sky-islands.tmp 0
execute as @e[tag=sky-islands.deep_dark] at @s if predicate sky-islands:in_overworld run scoreboard players add #overworld.update-count sky-islands.tmp 1
execute as @e[tag=sky-islands.village] at @s if predicate sky-islands:in_overworld run scoreboard players add #overworld.update-count sky-islands.tmp 1
execute if score #overworld.update-count sky-islands.tmp matches ..1 run return fail
data modify storage sky-islands:init overworld.updated set value 1
execute in minecraft:overworld run forceload remove all