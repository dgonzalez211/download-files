function sky-islands:island/version_check/updates/1/overworld/random_position
data modify storage forceload-async:data input.callback set value "sky-islands:island/version_check/updates/1/overworld/village/validate"

function forceload-async:forceload