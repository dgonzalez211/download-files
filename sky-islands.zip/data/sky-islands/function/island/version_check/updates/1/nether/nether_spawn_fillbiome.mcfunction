# --- Layer 1 (Y: 0 to 9) ---
execute positioned ~0 ~0 ~0 run fillbiome ~ ~ ~ ~19 ~9 ~19 minecraft:soul_sand_valley
execute positioned ~20 ~0 ~0 run fillbiome ~ ~ ~ ~9 ~9 ~19 minecraft:soul_sand_valley
execute positioned ~0 ~0 ~20 run fillbiome ~ ~ ~ ~19 ~9 ~9 minecraft:soul_sand_valley
execute positioned ~20 ~0 ~20 run fillbiome ~ ~ ~ ~9 ~9 ~9 minecraft:soul_sand_valley
# --- Layer 2 (Y: 10 to 19) ---
execute positioned ~0 ~10 ~0 run fillbiome ~ ~ ~ ~19 ~9 ~19 minecraft:soul_sand_valley
execute positioned ~20 ~10 ~0 run fillbiome ~ ~ ~ ~9 ~9 ~19 minecraft:soul_sand_valley
execute positioned ~0 ~10 ~20 run fillbiome ~ ~ ~ ~19 ~9 ~9 minecraft:soul_sand_valley
execute positioned ~20 ~10 ~20 run fillbiome ~ ~ ~ ~9 ~9 ~9 minecraft:soul_sand_valley
# --- Layer 3 (Y: 20 to 29) ---
execute positioned ~0 ~20 ~0 run fillbiome ~ ~ ~ ~19 ~9 ~19 minecraft:soul_sand_valley
execute positioned ~20 ~20 ~0 run fillbiome ~ ~ ~ ~9 ~9 ~19 minecraft:soul_sand_valley
execute positioned ~0 ~20 ~20 run fillbiome ~ ~ ~ ~19 ~9 ~9 minecraft:soul_sand_valley
execute positioned ~20 ~20 ~20 run fillbiome ~ ~ ~ ~9 ~9 ~9 minecraft:soul_sand_valley