function sky-islands:island/version_check/updates/1/overworld/deep_dark/load
function sky-islands:island/version_check/updates/1/overworld/village/load
data modify storage sky-islands:init overworld.version set value 1
