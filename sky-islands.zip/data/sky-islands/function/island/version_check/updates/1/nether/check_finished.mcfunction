execute if data storage sky-islands:init {nether:{updated:1}} run return fail
scoreboard players set #nether.update-count sky-islands.tmp 0
execute as @e[tag=sky-islands.basalt_deltas] at @s if predicate sky-islands:in_nether run scoreboard players add #nether.update-count sky-islands.tmp 1
execute if score #nether.update-count sky-islands.tmp matches ..0 run return fail
data modify storage sky-islands:init nether.updated set value 1
execute in minecraft:the_nether run forceload remove all