execute in minecraft:overworld run function sky-islands:island/version_check/updates/1/overworld/update
execute if data storage player-events:loaded-first {the_nether:1b} run execute in minecraft:the_nether run function sky-islands:island/version_check/updates/1/nether/update

#execute in minecraft:overworld run function sky-islands:island/version_check/updates/2/overworld/update
#execute if data storage player-events:loaded-first {the_nether:1b} run execute in minecraft:the_nether run function sky-islands:island/version_check/updates/2/nether/update