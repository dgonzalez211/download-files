execute if data storage sky-islands:init {overworld:{version:1}} run function sky-islands:island/version_check/updates/1/overworld/check_finished
execute if data storage sky-islands:init {nether:{version:1}} run execute in minecraft:the_nether run function sky-islands:island/version_check/updates/1/nether/check_finished

#execute if data storage sky-islands:init {overworld:{version:2}} run function sky-islands:island/version_check/updates/2/overworld/check_finished
#execute if data storage sky-islands:init {nether:{version:2}} run execute in minecraft:the_nether function sky-islands:island/version_check/updates/2/nether/check_finished
