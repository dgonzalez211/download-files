function sky-islands:island/overworld/load

data modify storage sky-islands:init overworld.version set value 1
data modify storage sky-islands:init initialized set value 1b
