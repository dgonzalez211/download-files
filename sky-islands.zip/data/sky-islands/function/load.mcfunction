scoreboard objectives add sky-islands.tmp dummy

scoreboard players set #random_range_overworld sky-islands.tmp 400
scoreboard players set #random_range_nether sky-islands.tmp 100
scoreboard players set #validation_fails_overworld sky-islands.tmp 0
scoreboard players set #validation_fails_nether sky-islands.tmp 0

execute unless data storage sky-islands:init initialized run function sky-islands:init
function sky-islands:island/version_check/run_update