function sky-islands:island/overworld/check_finished
function sky-islands:island/nether/check_finished
function sky-islands:island/version_check/check_finished