
scoreboard players add #players.total player-events.global 1
execute if score @s player-events.joined matches 1.. run function player-events:event/joined-again
execute unless entity @s[tag=player-events.joined-first] run function player-events:event/joined-first
execute if score @s player-events.died matches 1.. run function player-events:event/died
execute if entity @s[tag=player-events.waiting_for_respawn] if score @s player-events.respawned matches 1.. run function player-events:event/respawned