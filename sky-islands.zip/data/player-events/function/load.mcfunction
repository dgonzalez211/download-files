
scoreboard objectives add player-events.joined custom:leave_game
scoreboard objectives add player-events.died custom:deaths
scoreboard objectives add player-events.respawned custom:time_since_death
scoreboard objectives add player-events.global dummy