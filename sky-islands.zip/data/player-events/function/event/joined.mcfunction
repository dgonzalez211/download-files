
scoreboard players add #players.joined player-events.global 1
function #player-events:joined