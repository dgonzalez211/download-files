
scoreboard players reset @s player-events.joined

function #player-events:joined-again
function player-events:event/joined