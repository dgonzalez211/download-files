
execute if data storage player-events:loaded-first {the_end:1b} run return fail

data modify storage player-events:loaded-first the_end set value 1b

execute at @s run function #player-events:loaded-first/the_end