
execute if data storage player-events:loaded-first {overworld:1b} run return fail

data modify storage player-events:loaded-first overworld set value 1b

function #player-events:loaded-first/overworld