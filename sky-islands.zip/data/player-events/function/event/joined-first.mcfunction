
tag @s add player-events.joined-first

function player-events:event/loaded-first/overworld

function #player-events:joined-first
function player-events:event/joined