
function #player-events:left

scoreboard players remove #players.left player-events.global 1
execute if score #players.left player-events.global matches 1.. run function player-events:event/left