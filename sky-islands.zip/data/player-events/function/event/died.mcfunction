
scoreboard players reset @s player-events.died

tag @s add player-events.waiting_for_respawn

function #player-events:died