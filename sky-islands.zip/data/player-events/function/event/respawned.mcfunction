
tag @s remove player-events.waiting_for_respawn

function #player-events:respawned