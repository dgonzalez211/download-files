
# reset player counts
scoreboard players set #players.total player-events.global 0
scoreboard players set #players.joined player-events.global 0

# tick for each player (counts players)
execute as @a at @s rotated as @s run function player-events:tick_player

# calculate left players
scoreboard players operation #players.left player-events.global = #players.previous player-events.global
scoreboard players operation #players.left player-events.global += #players.joined player-events.global
scoreboard players operation #players.left player-events.global -= #players.total player-events.global

# dispatch players left event for (but not as) each left player
execute if score #players.left player-events.global matches 1.. run function player-events:event/left

# store total as previous for next tick
scoreboard players operation #players.previous player-events.global = #players.total player-events.global