
execute if data storage forceload-async:data current run return fail
execute unless data storage forceload-async:data queue[0] run return fail

# load next queue item
data modify storage forceload-async:data current set from storage forceload-async:data queue[0]
data remove storage forceload-async:data queue[0]

function forceload-async:setup/setup
