
# copy to new
execute store result storage forceload-async:data new.start.x int 1 run scoreboard players get #start.x forceload-async.input
execute store result storage forceload-async:data new.start.z int 1 run scoreboard players get #start.z forceload-async.input
execute store result storage forceload-async:data new.end.x int 1 run scoreboard players get #end.x forceload-async.input
execute store result storage forceload-async:data new.end.z int 1 run scoreboard players get #end.z forceload-async.input
execute store result storage forceload-async:data new.context.x int 1 run scoreboard players get #context.x forceload-async.input
execute store result storage forceload-async:data new.context.y int 1 run scoreboard players get #context.y forceload-async.input
execute store result storage forceload-async:data new.context.z int 1 run scoreboard players get #context.z forceload-async.input
data modify storage forceload-async:data new.context.dimension set from storage forceload-async:data input.context.dimension
execute if data storage forceload-async:data input.callback run data modify storage forceload-async:data new.callback set from storage forceload-async:data input.callback

# add to queue
data modify storage forceload-async:data queue append from storage forceload-async:data new

# clear new
data remove storage forceload-async:data new