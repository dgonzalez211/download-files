
tag @s add forceload-async.chunk

execute store result entity @s Pos[0] double 1 run scoreboard players get #x forceload-async.current
execute store result entity @s Pos[1] double 1 run scoreboard players get #y forceload-async.current
execute store result entity @s Pos[2] double 1 run scoreboard players get #z forceload-async.current

execute at @s run forceload add ~ ~

# finished all chunks
execute if score #x forceload-async.current >= #end.x forceload-async.current \
    if score #z forceload-async.current >= #end.z forceload-async.current \
    run return 1

# next chunk
execute if score #x forceload-async.current >= #end.x forceload-async.current run return run function forceload-async:setup/chunk/next_z
function forceload-async:setup/chunk/next_x
