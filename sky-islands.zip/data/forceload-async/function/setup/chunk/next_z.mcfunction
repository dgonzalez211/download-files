scoreboard players operation #z forceload-async.current += #chunk.size forceload-async.current
scoreboard players operation #x forceload-async.current = #start.x forceload-async.current
function forceload-async:setup/prepare_chunk