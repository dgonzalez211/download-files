scoreboard players operation #x forceload-async.current += #chunk.size forceload-async.current
function forceload-async:setup/prepare_chunk