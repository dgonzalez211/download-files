
scoreboard objectives remove forceload-async.current
scoreboard objectives add forceload-async.current dummy

# load positions
scoreboard players set #chunk.size forceload-async.current 16
execute store result score #start.x forceload-async.current run data get storage forceload-async:data current.start.x
scoreboard players operation #x forceload-async.current = #start.x forceload-async.current
execute store result score #y forceload-async.current run data get storage forceload-async:data current.context.y
execute store result score #z forceload-async.current run data get storage forceload-async:data current.start.z
execute store result score #end.x forceload-async.current run data get storage forceload-async:data current.end.x
execute store result score #end.z forceload-async.current run data get storage forceload-async:data current.end.z

# calculate expected chunks
scoreboard players operation #chunks.x forceload-async.current = #end.x forceload-async.current
scoreboard players operation #chunks.x forceload-async.current -= #x forceload-async.current
scoreboard players operation #chunks.x forceload-async.current /= #chunk.size forceload-async.current
scoreboard players add #chunks.x forceload-async.current 1
scoreboard players operation #chunks.z forceload-async.current = #end.z forceload-async.current
scoreboard players operation #chunks.z forceload-async.current -= #z forceload-async.current
scoreboard players operation #chunks.z forceload-async.current /= #chunk.size forceload-async.current
scoreboard players add #chunks.z forceload-async.current 1

scoreboard players operation #chunks.total forceload-async.current = #chunks.x forceload-async.current
scoreboard players operation #chunks.total forceload-async.current *= #chunks.z forceload-async.current
scoreboard players set #chunks.current forceload-async.current 0

# summon chunk markers and forceload them
function forceload-async:setup/prepare_chunk