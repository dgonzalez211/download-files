execute if data storage forceload-async:data {current:{context:{dimension:"minecraft:overworld"}}} \
    in minecraft:overworld summon marker run return run function forceload-async:setup/chunk
execute if data storage forceload-async:data {current:{context:{dimension:"minecraft:the_nether"}}} \
    in minecraft:the_nether summon marker run return run function forceload-async:setup/chunk
execute if data storage forceload-async:data {current:{context:{dimension:"minecraft:the_end"}}} \
    in minecraft:the_end summon marker run return run function forceload-async:setup/chunk