
# input storage: forceload-async:data 
# path: input
# { 
#   context: {
#     x: <int>,
#     y: <int>,
#     z: <int>,
#     dimension: <string>,
#   },
#   from: {
#     x: { relative: <int>, absolute: <int> },
#     z: { relative: <int>, absolute: <int> },
#   },
#   to: {
#     x: { relative: <int>, absolute: <int>, delta: <int> },
#     z: { relative: <int>, absolute: <int>, delta: <int> },
#   },
#   callback: "datapack:function"
# }

# Everything is optional
# - context falls back to the current execution position
# - from falls back to context
# - to falls back to from
# - if no callback is provided, no callback will be executed

# Positions
# - provide only one of relative, absolute or delta
# - relative is relative to the context position
# - absolute is an absolute position in the world
# - delta is relative to the start position

# Callback
# - is called when all chunks are loaded
# - will be called at the context position (rounded down)
# - does not preserve the entity context

# Queue
# - forceloads cannot run in parallel
# - you can still call this function, the forceload will be queued


execute summon marker run function forceload-async:calculate/all
function forceload-async:queue/add
function forceload-async:queue/try_next

# reset
scoreboard objectives remove forceload-async.input
data remove storage forceload-async:data input