
# absolute
execute if data storage forceload-async:data input.to.x.absolute \
    store result score #end.x forceload-async.input \
    run return run data get storage forceload-async:data input.to.x.absolute

# relative
execute if data storage forceload-async:data input.to.x.relative \
    store result score #end.x forceload-async.input \
    run data get storage forceload-async:data input.to.x.relative
execute if data storage forceload-async:data input.to.x.relative \
    run return run scoreboard players operation #end.x forceload-async.input += #context.x forceload-async.input

# delta
execute if data storage forceload-async:data input.to.x.delta \
    store result score #end.x forceload-async.input \
    run data get storage forceload-async:data input.to.x.delta
execute if data storage forceload-async:data input.to.x.relative \
    run return run scoreboard players operation #end.x forceload-async.input += #start.x forceload-async.input

# fallback to start
scoreboard players operation #end.x forceload-async.input = #start.x forceload-async.input