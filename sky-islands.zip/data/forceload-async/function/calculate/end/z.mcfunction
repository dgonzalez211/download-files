
# absolute
execute if data storage forceload-async:data input.to.z.absolute \
    store result score #end.z forceload-async.input \
    run return run data get storage forceload-async:data input.to.z.absolute

# relative
execute if data storage forceload-async:data input.to.z.relative \
    store result score #end.z forceload-async.input \
    run data get storage forceload-async:data input.to.z.relative
execute if data storage forceload-async:data input.to.z.relative \
    run return run scoreboard players operation #end.z forceload-async.input += #context.z forceload-async.input

# delta
execute if data storage forceload-async:data input.to.z.delta \
    store result score #end.z forceload-async.input \
    run data get storage forceload-async:data input.to.z.delta
execute if data storage forceload-async:data input.to.z.relative \
    run return run scoreboard players operation #end.z forceload-async.input += #start.z forceload-async.input

# fallback to start
scoreboard players operation #end.z forceload-async.input = #start.z forceload-async.input