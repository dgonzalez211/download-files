
execute if score #start.x forceload-async.input > #end.x forceload-async.input run \
    scoreboard players operation #start.x forceload-async.input >< #end.x forceload-async.input

execute if score #start.z forceload-async.input > #end.z forceload-async.input run \
    scoreboard players operation #start.z forceload-async.input >< #end.z forceload-async.input