
scoreboard players set #chunk.size forceload-async.input 16
scoreboard players operation #diff forceload-async.input = #start.x forceload-async.input
scoreboard players operation #diff forceload-async.input %= #chunk.size forceload-async.input
scoreboard players operation #start.x forceload-async.input -= #diff forceload-async.input

scoreboard players operation #diff forceload-async.input = #start.z forceload-async.input
scoreboard players operation #diff forceload-async.input %= #chunk.size forceload-async.input
scoreboard players operation #start.z forceload-async.input -= #diff forceload-async.input

scoreboard players operation #diff forceload-async.input = #end.x forceload-async.input
scoreboard players operation #diff forceload-async.input %= #chunk.size forceload-async.input
scoreboard players operation #end.x forceload-async.input -= #diff forceload-async.input

scoreboard players operation #diff forceload-async.input = #end.z forceload-async.input
scoreboard players operation #diff forceload-async.input %= #chunk.size forceload-async.input
scoreboard players operation #end.z forceload-async.input -= #diff forceload-async.input

