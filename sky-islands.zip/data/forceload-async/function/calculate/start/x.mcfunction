
# absolute
execute if data storage forceload-async:data input.from.x.absolute \
    store result score #start.x forceload-async.input \
    run return run data get storage forceload-async:data input.from.x.absolute

# relative
execute if data storage forceload-async:data input.from.x.relative \
    store result score #start.x forceload-async.input \
    run data get storage forceload-async:data input.from.x.relative
execute if data storage forceload-async:data input.from.x.relative \
    run return run scoreboard players operation #start.x forceload-async.input += #context.x forceload-async.input

# fallback to context
scoreboard players operation #start.x forceload-async.input = #context.x forceload-async.input