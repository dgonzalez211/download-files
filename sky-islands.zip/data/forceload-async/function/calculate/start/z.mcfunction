
# absolute
execute if data storage forceload-async:data input.from.z.absolute \
    store result score #start.z forceload-async.input \
    run return run data get storage forceload-async:data input.from.z.absolute

# relative
execute if data storage forceload-async:data input.from.z.relative \
    store result score #start.z forceload-async.input \
    run data get storage forceload-async:data input.from.z.relative
execute if data storage forceload-async:data input.from.z.relative \
    run return run scoreboard players operation #start.z forceload-async.input += #context.z forceload-async.input

# fallback to context
scoreboard players operation #start.z forceload-async.input = #context.z forceload-async.input