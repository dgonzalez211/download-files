
scoreboard objectives remove forceload-async.input
scoreboard objectives add forceload-async.input dummy

function forceload-async:calculate/context

function forceload-async:calculate/start/x
function forceload-async:calculate/start/z

function forceload-async:calculate/end/x
function forceload-async:calculate/end/z

function forceload-async:calculate/swap
function forceload-async:calculate/align

kill @s