
execute store result score #context.x forceload-async.input run data get entity @s Pos[0]
execute store result score #context.y forceload-async.input run data get entity @s Pos[1]
execute store result score #context.z forceload-async.input run data get entity @s Pos[2]

execute if data storage forceload-async:data input.context.x \
    store result score #context.x forceload-async.input run \
    data get storage forceload-async:data input.context.x

execute if data storage forceload-async:data input.context.y \
    store result score #context.y forceload-async.input run \
    data get storage forceload-async:data input.context.y

execute if data storage forceload-async:data input.context.z \
    store result score #context.z forceload-async.input run \
    data get storage forceload-async:data input.context.z

execute unless data storage forceload-async:data input.context.dimension \
    if dimension minecraft:overworld \
    run data modify storage forceload-async:data input.context.dimension set value "minecraft:overworld"

execute unless data storage forceload-async:data input.context.dimension \
    if dimension minecraft:the_nether \
    run data modify storage forceload-async:data input.context.dimension set value "minecraft:the_nether"

execute unless data storage forceload-async:data input.context.dimension \
    if dimension minecraft:the_end \
    run data modify storage forceload-async:data input.context.dimension set value "minecraft:the_end"