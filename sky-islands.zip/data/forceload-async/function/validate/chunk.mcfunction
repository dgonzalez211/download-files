
kill @s

execute unless data storage forceload-async:data current run return fail

scoreboard players add #chunks.current forceload-async.current 1
execute if score #chunks.current forceload-async.current >= #chunks.total forceload-async.current run function forceload-async:finish/finish