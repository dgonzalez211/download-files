
execute as @e[type=marker,tag=forceload-async.chunk] run function forceload-async:validate/chunk