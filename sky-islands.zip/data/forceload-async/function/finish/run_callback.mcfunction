
execute store result storage forceload-async:data callback.x int 1 run data get storage forceload-async:data current.context.x
execute store result storage forceload-async:data callback.y int 1 run data get storage forceload-async:data current.context.y
execute store result storage forceload-async:data callback.z int 1 run data get storage forceload-async:data current.context.z
data modify storage forceload-async:data callback.function set from storage forceload-async:data current.callback
data modify storage forceload-async:data callback.dimension set from storage forceload-async:data current.context.dimension

function forceload-async:finish/callback with storage forceload-async:data callback

data remove storage forceload-async:data callback