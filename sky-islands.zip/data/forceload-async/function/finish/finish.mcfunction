
execute if data storage forceload-async:data current.callback run function forceload-async:finish/run_callback

# reset
data remove storage forceload-async:data current
scoreboard objectives remove forceload-async.current